/*
 * Copyright (c) 2024 Weasis Team and other contributors.
 *
 * This program and the accompanying materials are made available under the terms of the Eclipse
 * Public License 2.0 which is available at https://www.eclipse.org/legal/epl-2.0, or the Apache
 * License, Version 2.0 which is available at https://www.apache.org/licenses/LICENSE-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
 */
package org.weasis.dicom.hp;

import org.weasis.core.util.annotations.Generated;

public class AbstractPriorValue {

  private final int start;
  private final int end;

  public AbstractPriorValue(int start, int end) {
    this.start = start;
    this.end = end;
  }

  AbstractPriorValue(int[] value) {
    this(value[0], value[1]);
  }

  @Generated
  final int[] getValues() {
    return new int[] {start, end};
  }

  @Generated
  public final int getStart() {
    return start;
  }

  @Generated
  public final int getEnd() {
    return end;
  }
}
