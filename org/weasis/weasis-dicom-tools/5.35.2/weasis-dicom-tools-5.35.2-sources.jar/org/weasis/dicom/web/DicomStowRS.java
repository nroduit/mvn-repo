/*
 * Copyright (c) 2020 Weasis Team and other contributors.
 *
 * This program and the accompanying materials are made available under the terms of the Eclipse
 * Public License 2.0 which is available at https://www.eclipse.org/legal/epl-2.0, or the Apache
 * License, Version 2.0 which is available at https://www.apache.org/licenses/LICENSE-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
 */
package org.weasis.dicom.web;

import static org.weasis.dicom.web.MultipartConstants.CONTENT_TYPE;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.SequenceInputStream;
import java.io.UncheckedIOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpHeaders;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;
import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Sequence;
import org.dcm4che3.data.Tag;
import org.dcm4che3.img.DicomImageReadParam;
import org.dcm4che3.img.DicomImageReader;
import org.dcm4che3.img.DicomJpegWriteParam;
import org.dcm4che3.img.DicomOutputData;
import org.dcm4che3.img.Transcoder;
import org.dcm4che3.img.stream.BytesWithImageDescriptor;
import org.dcm4che3.img.stream.ImageAdapter.AdaptTransferSyntax;
import org.dcm4che3.img.util.Editable;
import org.dcm4che3.io.ContentHandlerAdapter;
import org.dcm4che3.io.DicomOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.weasis.core.util.annotations.Generated;
import org.weasis.opencv.data.PlanarImage;
import org.xml.sax.SAXException;

/**
 * DICOM Store Over Web (STOW-RS) client implementation. Provides methods for uploading DICOM data
 * using multipart/related HTTP requests. Supports file uploads, stream uploads, and metadata-only
 * uploads.
 *
 * @see <a href="http://dicom.nema.org/medical/dicom/current/output/html/part18.html">DICOM
 *     PS3.18</a>
 */
public class DicomStowRS implements AutoCloseable {

  private static final Logger LOGGER = LoggerFactory.getLogger(DicomStowRS.class);

  /** Default multipart boundary string */
  public static final String DEFAULT_BOUNDARY = "weasisDicomBoundary";

  private final DicomStowConfig config;
  private final HttpClient httpClient;
  private final ExecutorService executorService;

  /** Creates a STOW-RS client with the specified configuration. */
  public DicomStowRS(DicomStowConfig config) {
    this.config = Objects.requireNonNull(config, "Configuration cannot be null");
    this.executorService = createExecutorService();
    this.httpClient = createHttpClient();
    HttpAuthorization.warnIfUnencrypted(config.getAuthorization(), config.getRequestUrl());
  }

  /**
   * Creates a client sharing {@code httpClient}, e.g. to reuse its connection pool. The caller is
   * responsible for its redirect policy: following redirects may replay the credentials to another
   * origin.
   */
  public DicomStowRS(DicomStowConfig config, HttpClient httpClient) {
    this.config = Objects.requireNonNull(config, "Configuration cannot be null");
    this.executorService = null;
    this.httpClient = Objects.requireNonNull(httpClient, "HTTP client cannot be null");
    HttpAuthorization.warnIfUnencrypted(config.getAuthorization(), config.getRequestUrl());
  }

  /** Legacy constructor for backward compatibility. */
  public DicomStowRS(
      String requestURL, ContentType contentType, String agentName, Map<String, String> headers) {
    this(requestURL, contentType, agentName, headers, DicomStowConfig.DEFAULT_HTTP_VERSION);
  }

  /** Legacy constructor allowing the caller to pick the HTTP protocol version. */
  public DicomStowRS(
      String requestURL,
      ContentType contentType,
      String agentName,
      Map<String, String> headers,
      HttpClient.Version httpVersion) {
    this(
        DicomStowConfig.builder()
            .requestUrl(requestURL)
            .contentType(contentType)
            .userAgent(agentName)
            .headers(headers)
            .httpVersion(httpVersion)
            .build());
  }

  /** Uploads a DICOM file from the specified path. */
  public void uploadDicom(Path path) throws IOException, InterruptedException {
    Objects.requireNonNull(path, "Path cannot be null");
    if (!Files.exists(path)) {
      throw new IllegalArgumentException("File does not exist: " + path);
    }

    uploadPayload(Payload.ofPath(path));
  }

  /** Uploads DICOM data from an input stream with file meta information. */
  public void uploadDicom(InputStream inputStream, Attributes fileMetaInfo)
      throws IOException, InterruptedException {
    Objects.requireNonNull(inputStream, "Input stream cannot be null");
    Objects.requireNonNull(fileMetaInfo, "File meta information cannot be null");

    Payload payload = createStreamPayload(inputStream, fileMetaInfo);
    uploadPayload(payload);
  }

  /** Uploads DICOM metadata as a new dataset. */
  public void uploadDicom(Attributes metadata, String transferSyntaxUid)
      throws IOException, InterruptedException {
    Objects.requireNonNull(metadata, "Metadata cannot be null");
    Objects.requireNonNull(transferSyntaxUid, "Transfer syntax UID cannot be null");

    Payload payload = createMetadataPayload(metadata, transferSyntaxUid);
    uploadPayload(payload);
  }

  /** Uploads a prepared payload. */
  public void uploadPayload(Payload payload) throws IOException, InterruptedException {
    Objects.requireNonNull(payload, "Payload cannot be null");

    var multipartBody = new MultipartBody(config.getContentType(), DEFAULT_BOUNDARY);
    multipartBody.addPart(config.getContentType().getType(), payload, null);

    HttpRequest request = buildHttpRequest(multipartBody);
    HttpResponse<String> response = sendRequest(request, payload.isReplayable());

    logResponse(response);
    checkStoreResponse(response);
  }

  /**
   * Rejects a response that does not confirm the storage. A redirection that was not followed
   * stored nothing, and a 202 Accepted carrying a Failed SOP Sequence means that some instances
   * were not stored (PS3.18 10.5.3); a 202 with warnings only is accepted.
   *
   * @throws HttpException carrying the response status code
   */
  static void checkStoreResponse(HttpResponse<String> response) throws HttpException {
    int statusCode = response.statusCode();
    if (statusCode >= 300) {
      throw HttpException.fromResponse("STOW-RS request not completed", response);
    }
    if (statusCode == 202) {
      String failures = failedInstances(response.body());
      if (failures != null) {
        throw new HttpException(
            "STOW-RS failed to store: " + failures, statusCode, response.body(), null);
      }
    }
  }

  /**
   * Parses a DICOM Native XML response. The body comes from the server, so DTDs are refused: they
   * would let it make the parser read local files or reach other hosts (XXE).
   */
  static Attributes parseXml(String body)
      throws ParserConfigurationException, SAXException, IOException {
    SAXParserFactory factory = SAXParserFactory.newInstance();
    factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
    factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
    factory.setXIncludeAware(false);
    Attributes attributes = new Attributes();
    factory
        .newSAXParser()
        .parse(
            new ByteArrayInputStream(body.getBytes(StandardCharsets.UTF_8)),
            new ContentHandlerAdapter(attributes));
    return attributes;
  }

  /** Returns the failed instances listed in a STOW-RS XML response, or null if there is none. */
  static String failedInstances(String body) {
    if (body == null || body.isBlank()) {
      return null;
    }
    Attributes attributes;
    try {
      attributes = parseXml(body);
    } catch (Exception e) {
      LOGGER.warn("Cannot read the STOW-RS response, the failed instances are unknown", e);
      return null;
    }
    Sequence failed = attributes.getSequence(Tag.FailedSOPSequence);
    if (failed == null || failed.isEmpty()) {
      return null;
    }
    return failed.stream()
        .map(
            item ->
                item.getString(Tag.ReferencedSOPInstanceUID, "unknown SOP Instance UID")
                    + " (failure reason "
                    + item.getInt(Tag.FailureReason, -1)
                    + ")")
        .collect(Collectors.joining(", "));
  }

  @Override
  public void close() {
    if (executorService != null && !executorService.isShutdown()) {
      executorService.shutdown();
    }
  }

  // Getters for backward compatibility
  public ContentType getContentType() {
    return config.getContentType();
  }

  public String getRequestURL() {
    return config.getRequestUrl();
  }

  public Map<String, String> getHeaders() {
    return config.getHeaders();
  }

  /** Creates a payload for processing compressed DICOM images. */
  public static Payload createCompressedImagePayload(
      Attributes data,
      AdaptTransferSyntax syntax,
      BytesWithImageDescriptor desc,
      Editable<PlanarImage> editable) {
    return new CompressedImagePayload(data, syntax, desc, editable);
  }

  private ExecutorService createExecutorService() {
    return Executors.newFixedThreadPool(
        config.getThreadPoolSize(),
        r -> {
          Thread thread = new Thread(r, "DicomStow-" + System.currentTimeMillis());
          thread.setDaemon(true);
          return thread;
        });
  }

  private HttpClient createHttpClient() {
    return HttpClient.newBuilder()
        .executor(executorService)
        .followRedirects(HttpAuthorization.redirectPolicy(config.getAuthorization()))
        .version(config.getHttpVersion())
        .connectTimeout(config.getConnectTimeout())
        .build();
  }

  private HttpRequest buildHttpRequest(MultipartBody multipartBody) {
    HttpRequest.Builder builder =
        HttpRequest.newBuilder()
            .uri(URI.create(config.getRequestUrl()))
            .POST(multipartBody.createBodyPublisher())
            .header(CONTENT_TYPE, multipartBody.getContentTypeHeader())
            .header("Accept", MultipartConstants.DicomContentType.XML.getMimeType())
            .header("User-Agent", config.getUserAgent())
            .expectContinue(config.useExpectContinue(multipartBody.getPayloadSize()));
    config.getRequestTimeout().ifPresent(builder::timeout);

    // Add custom headers
    config.getHeaders().forEach(builder::header);

    HttpRequest request = builder.build();

    if (LOGGER.isDebugEnabled()) {
      logRequest(request, multipartBody);
    }

    return request;
  }

  // The multipart publisher re-opens the payload streams, so a replayable request can be resent.
  HttpResponse<String> sendRequest(HttpRequest request, boolean replayable)
      throws IOException, InterruptedException {
    HttpResponse<String> response =
        HttpAuthorization.send(
            httpClient,
            config.getAuthorization(),
            request,
            HttpResponse.BodyHandlers.ofString(),
            replayable);

    int statusCode = response.statusCode();
    if (statusCode >= 400) {
      throw HttpException.fromResponse(response);
    }

    return response;
  }

  @Generated
  private void logRequest(HttpRequest request, MultipartBody multipartBody) {
    URI uri = request.uri();
    LOGGER.debug(
        "> POST {} {}", uri.getPath(), request.version().orElse(HttpClient.Version.HTTP_1_1));
    LOGGER.debug("> Host: {}:{}", uri.getHost(), uri.getPort());
    logHeaders("> ", request.headers());
    multipartBody.logDebugInfo();
  }

  @Generated
  private void logResponse(HttpResponse<String> response) {
    if (LOGGER.isDebugEnabled()) {
      LOGGER.debug("< {} response code: {}", response.version(), response.statusCode());
      logHeaders("< ", response.headers());
    }

    // Log response body lines
    response.body().lines().forEach(LOGGER::info);
  }

  @Generated
  private static void logHeaders(String prefix, HttpHeaders headers) {
    headers
        .map()
        .forEach(
            (name, values) ->
                values.forEach(value -> LOGGER.debug("{}{}: {}", prefix, name, value)));
    LOGGER.debug(prefix.trim());
  }

  private Payload createStreamPayload(InputStream inputStream, Attributes fileMetaInfo) {
    return new Payload() {
      @Override
      public long size() {
        return -1; // Unknown size for streams
      }

      @Override
      public boolean isReplayable() {
        return false;
      }

      @Override
      public InputStream newInputStream() {
        try {
          var metaOutput = new ByteArrayOutputStream();
          try (var dicomOut =
              new DicomOutputStream(metaOutput, fileMetaInfo.getString(Tag.TransferSyntaxUID))) {
            dicomOut.writeFileMetaInformation(fileMetaInfo);
          }

          List<InputStream> streams = new ArrayList<>();
          streams.add(new ByteArrayInputStream(metaOutput.toByteArray()));
          streams.add(inputStream);

          return new SequenceInputStream(Collections.enumeration(streams));
        } catch (IOException e) {
          // Failing the upload, an empty part would be sent as if it were the instance
          throw new UncheckedIOException("Failed to create stream payload", e);
        }
      }
    };
  }

  private Payload createMetadataPayload(Attributes metadata, String transferSyntaxUid) {
    return new Payload() {
      @Override
      public long size() {
        return -1;
      }

      @Override
      public boolean isReplayable() {
        return true;
      }

      @Override
      public InputStream newInputStream() {
        try {
          Attributes fileMetaInfo = metadata.createFileMetaInformation(transferSyntaxUid);
          var output = new ByteArrayOutputStream();

          try (var dicomOut = new DicomOutputStream(output, transferSyntaxUid)) {
            dicomOut.writeDataset(fileMetaInfo, metadata);
          }

          return new ByteArrayInputStream(output.toByteArray());
        } catch (IOException e) {
          throw new UncheckedIOException("Failed to create metadata payload", e);
        }
      }
    };
  }

  /** Payload for compressed DICOM images. */
  private record CompressedImagePayload(
      Attributes data,
      AdaptTransferSyntax syntax,
      BytesWithImageDescriptor descriptor,
      Editable<PlanarImage> editable)
      implements Payload {
    private CompressedImagePayload(
        Attributes data,
        AdaptTransferSyntax syntax,
        BytesWithImageDescriptor descriptor,
        Editable<PlanarImage> editable) {
      this.data = Objects.requireNonNull(data);
      this.syntax = Objects.requireNonNull(syntax);
      this.descriptor = Objects.requireNonNull(descriptor);
      this.editable = Objects.requireNonNull(editable);
    }

    @Override
    public long size() {
      return -1; // Compressed size is unknown
    }

    @Override
    public boolean isReplayable() {
      return true; // Transcodes again from the source attributes
    }

    @Override
    public InputStream newInputStream() {
      try {
        return createCompressedStream();
      } catch (IOException e) {
        throw new UncheckedIOException("Failed to create compressed image stream", e);
      }
    }

    private InputStream createCompressedStream() throws IOException {
      var reader = new DicomImageReader(Transcoder.dicomImageReaderSpi);

      try {
        reader.setInput(descriptor);

        var readParam = new DicomImageReadParam();
        readParam.setReleaseImageAfterProcessing(true);

        var images = reader.getLazyPlanarImages(readParam, editable);
        var outputData =
            new DicomOutputData(images, descriptor.getImageDescriptor(), syntax.getRequested());

        if (!syntax.getRequested().equals(outputData.getTsuid())) {
          syntax.setSuitable(outputData.getTsuid());
          LOGGER.warn(
              "Transcoding to {} not possible, using {} instead",
              syntax.getRequested(),
              syntax.getSuitable());
        }

        Attributes dataset = new Attributes(data);
        dataset.remove(Tag.PixelData);

        var output = new ByteArrayOutputStream();
        try (var dicomOut = new DicomOutputStream(output, outputData.getTsuid())) {
          dicomOut.writeFileMetaInformation(
              dataset.createFileMetaInformation(outputData.getTsuid()));

          if (DicomOutputData.isNativeSyntax(outputData.getTsuid())) {
            outputData.writeRawImageData(dicomOut, dataset);
          } else {
            int[] writeParams =
                outputData.adaptTagsToCompressedImage(
                    dataset,
                    outputData.getFirstImage().get(),
                    descriptor.getImageDescriptor(),
                    DicomJpegWriteParam.buildDicomImageWriteParam(outputData.getTsuid()));
            outputData.writeCompressedImageData(dicomOut, dataset, writeParams);
          }
        }

        return new ByteArrayInputStream(output.toByteArray());
      } finally {
        reader.dispose();
      }
    }
  }
}
