/*
 * Bibliothek - DockingFrames
 * Library built on Java/Swing, allows the user to "drag and drop"
 * panels containing any Swing-Component the developer likes to add.
 *
 * Copyright (C) 2010 Benjamin Sigg
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Benjamin Sigg
 * benjamin_sigg@gmx.ch
 * CH - Switzerland
 */
package bibliothek.gui.dock.util.icon;

import bibliothek.gui.DockController;
import bibliothek.gui.DockUI;
import bibliothek.gui.dock.station.stack.tab.TabMenuDockIcon;
import bibliothek.gui.dock.themes.icon.TabMenuOverflowIconBridge;
import bibliothek.gui.dock.util.DockUtilities;
import bibliothek.gui.dock.util.UIProperties;
import bibliothek.gui.dock.util.UIScheme;
import bibliothek.gui.dock.util.UISchemeEvent;
import bibliothek.util.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.Icon;

/**
 * This default implementation of an {@link UIScheme} for {@link Icon}s reads an ini-file which
 * consists of "key=icon-path" pairs, and loads all the icons described in that ini file when
 * needed.
 *
 * @author Benjamin Sigg
 */
public class DefaultIconScheme extends AbstractIconScheme {

  private final Map<String, Icon> icons;
  private final Map<Path, DockIconBridge> bridges;

  /**
   * Creates a new scheme loading first the contents of the ini file <code>file</code> and then the
   * icons that are found by analyzing the content of <code>file</code>.<br> If no file is found,
   * then this scheme just remains empty.
   *
   * @param folder       the file to read
   * @param controller the {@link DockController} in whose realm this scheme will be used
   */
  public DefaultIconScheme(String folder, List<String> resources, DockController controller) {
    this(folder, resources, DefaultIconScheme.class.getClassLoader(), controller);
  }

  /**
   * Creates a new scheme loading first the contents of the ini file <code>file</code> and then the
   * icons that are found by analyzing the content of <code>file</code>.<br> If no file is found,
   * then this scheme just remains empty.
   *
   * @param folder       the file to read
   * @param loader     the {@link ClassLoader} whose {@link ClassLoader#getResource(String)} method
   *                   will be used to load any files
   * @param controller the {@link DockController} in whose realm this scheme will be used
   */
  public DefaultIconScheme(String folder, List<String> resources, ClassLoader loader, DockController controller) {
    super(controller);

    icons = new HashMap<>();
    bridges = new HashMap<>();

    initHardcoded();
    icons.putAll(DockUtilities.loadIcons(folder, resources, icons.keySet(), loader));
  }

  /**
   * Called by the constructor of this class, initializes some hard coded icons.
   */
  protected void initHardcoded() {
    setBridge(TabMenuDockIcon.KIND_TAB_MENU, new TabMenuOverflowIconBridge());
    setIcon(DockUI.OVERFLOW_MENU_ICON, DockUtilities.getDownArrowIcon());
  }

  public DockIconBridge getBridge(Path name,
      UIProperties<Icon, DockIcon, DockIconBridge> properties) {
    return bridges.get(name);
  }

  public Icon getResource(String name, UIProperties<Icon, DockIcon, DockIconBridge> properties) {
    return icons.get(name);
  }

  /**
   * Changes the icon with name <code>name</code> to <code>icon</code>. Please note that if <code>
   * name</code> was {@link #link(bibliothek.gui.dock.util.PropertyKey, String) linked}, the newly
   * set value may be overridden again.
   *
   * @param name the unique key of the icon
   * @param icon the new icon, can be <code>null</code>
   */
  public void setIcon(String name, Icon icon) {
    changed(name, icon);
  }

  /**
   * Sets the {@link DockIconBridge} with type <code>type</code>.
   *
   * @param type   the unique identifier of the type that should be handled by the new bridge
   * @param bridge the new bridge or <code>null</code>
   */
  public void setBridge(final Path type, DockIconBridge bridge) {
    if (bridge == null) {
      bridges.remove(type);
    } else {
      bridges.put(type, bridge);
    }

    fire(new UISchemeEvent<>() {
      public Collection<Path> changedBridges(Set<Path> names) {
        List<Path> result = new ArrayList<>();
        if (names == null || names.contains(type)) {
          result.add(type);
        }
        return result;
      }

      public Collection<String> changedResources(Set<String> names) {
        return Collections.emptySet();
      }

      public UIScheme<Icon, DockIcon, DockIconBridge> getScheme() {
        return DefaultIconScheme.this;
      }
    });
  }

  @Override
  protected void changed(final String id, Icon icon) {
    if (icon == null) {
      icons.remove(id);
    } else {
      icons.put(id, icon);
    }

    fire(new UISchemeEvent<>() {
      public UIScheme<Icon, DockIcon, DockIconBridge> getScheme() {
        return DefaultIconScheme.this;
      }

      public Collection<String> changedResources(Set<String> names) {
        List<String> list = new ArrayList<>(1);
        if (names == null || names.contains(id)) {
          list.add(id);
        }
        return list;
      }

      public Collection<Path> changedBridges(Set<Path> names) {
        return Collections.emptySet();
      }
    });
  }
}
