/*
 * Bibliothek - DockingFrames
 * Library built on Java/Swing, allows the user to "drag and drop"
 * panels containing any Swing-Component the developer likes to add.
 *
 * Copyright (C) 2007 Benjamin Sigg
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Benjamin Sigg
 * benjamin_sigg@gmx.ch
 * CH - Switzerland
 */

package bibliothek.gui.dock.themes;

import bibliothek.gui.DockController;
import bibliothek.gui.DockTheme;

import java.lang.reflect.Constructor;
import java.net.URI;
import java.net.URISyntaxException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A factory using the {@link ThemeProperties} of a {@link DockTheme} to create instances of that
 * <code>DockTheme</code>.
 *
 * @param <T> the type of theme created by this factory
 * @author Benjamin Sigg
 */
public class ThemePropertyFactory<T extends DockTheme> implements ThemeFactory {
  private static final Logger LOGGER = LoggerFactory.getLogger( ThemePropertyFactory.class );
  /** Default constructor of the theme */
  private final Constructor<T> constructor;
  /** Information about the theme */
  private final ThemeProperties properties;

  /**
   * Creates a new factory.
   *
   * @param theme the class of a theme, must have the {@link ThemeProperties} annotation.
   */
  public ThemePropertyFactory(Class<T> theme) {
    if (theme == null) throw new IllegalArgumentException("Theme must not be null");

    properties = theme.getAnnotation(ThemeProperties.class);
    if (properties == null)
      throw new IllegalArgumentException("Theme misses annotation ThemeProperties");

    try {
      constructor = theme.getConstructor();
    } catch (NoSuchMethodException e) {
      throw new IllegalArgumentException("Missing default constructor", e);
    }
  }

  public T create(DockController controller) {
    try {
      return constructor.newInstance();
    } catch (Exception e) {
      LOGGER.error("Can't create theme due an unknown reason", e);
      return null;
    }
  }

  public ThemeMeta createMeta(DockController controller) {
    return new DefaultThemeMeta(
        this,
        controller,
        properties.nameBundle(),
        properties.descriptionBundle(),
        getAuthors(),
        getWebpages());
  }

  public String[] getAuthors() {
    return properties.authors();
  }

  public URI[] getWebpages() {
    try {
      String[] urls = properties.webpages();
      URI[] result = new URI[urls.length];
      for (int i = 0; i < result.length; i++) result[i] = new URI(urls[i]);

      return result;
    } catch (URISyntaxException ex) {
      LOGGER.error("Can't create urls due an unknown reason", ex);
      return null;
    }
  }
}
