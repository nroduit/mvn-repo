/*
 * Bibliothek - DockingFrames
 * Library built on Java/Swing, allows the user to "drag and drop"
 * panels containing any Swing-Component the developer likes to add.
 *
 * Copyright (C) 2010 Benjamin Sigg
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Benjamin Sigg
 * benjamin_sigg@gmx.ch
 * CH - Switzerland
 */
package bibliothek.gui.dock.themes;

import bibliothek.gui.DockController;
import bibliothek.gui.DockStation;
import bibliothek.gui.DockTheme;
import bibliothek.gui.Dockable;
import bibliothek.gui.dock.control.DockRegister;
import bibliothek.gui.dock.control.focus.DefaultFocusRequest;
import bibliothek.gui.dock.event.UIListener;
import bibliothek.gui.dock.station.Combiner;
import bibliothek.gui.dock.station.DisplayerFactory;
import bibliothek.gui.dock.station.StationPaint;
import bibliothek.gui.dock.station.span.SpanFactory;
import bibliothek.gui.dock.themes.border.BorderModifier;
import bibliothek.gui.dock.title.DockTitleManager;
import bibliothek.gui.dock.util.*;
import bibliothek.gui.dock.util.extension.ExtensionName;
import bibliothek.util.FrameworkOnly;

import javax.swing.*;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;

/**
 * The {@link ThemeManager} is responsible for collecting properties of the current {@link
 * DockTheme} and redistribute them. The {@link ThemeManager} provides facilities for clients to
 * modify and override properties of a theme without the need to access or change the {@link
 * DockTheme} itself.
 *
 * @author Benjamin Sigg
 */
public class ThemeManager extends TypedUIProperties {
  /** Identifier for a factory that creates {@link StationPaint}s. */
  public static final Type<StationPaint> STATION_PAINT_TYPE = new Type<>("StationPaint");

  /** unique identifier for the basic {@link StationPaint} */
  public static final String STATION_PAINT = "dock.paint";

  /** Identifier for the type {@link Combiner} */
  public static final Type<Combiner> COMBINER_TYPE = new Type<>("Combiner");

  /** unique identifier for the basic {@link Combiner} */
  public static final String COMBINER = "dock.combiner";

  /** Identifier for the type {@link DisplayerFactory} */
  public static final Type<DisplayerFactory> DISPLAYER_FACTORY_TYPE =
      new Type<>("DisplayerFactory");

  /** unique identifier for the basic {@link DisplayerFactory} */
  public static final String DISPLAYER_FACTORY = "dock.displayer";

  /** Identifier for the type {@link BackgroundPaint} */
  public static final Type<BackgroundPaint> BACKGROUND_PAINT_TYPE = new Type<>("BackgroundPaint");

  /** unique identifier for the basic {@link BackgroundPaint} */
  public static final String BACKGROUND_PAINT = "dock.background";

  /** Identifier for the type {@link BorderModifier} */
  public static final Type<BorderModifier> BORDER_MODIFIER_TYPE = new Type<>("BorderModifier");

  /** unique identifier for the basic {@link BorderModifier} */
  public static final String BORDER_MODIFIER = "dock.border";

  /** Identifier for the type {@link SpanFactory} */
  public static final Type<SpanFactory> SPAN_FACTORY_TYPE = new Type<>("SpanFactory");

  /** unique identifier for the basic {@link SpanFactory} */
  public static final String SPAN_FACTORY = "dock.spanFactory";

  /** the controller owning the manager */
  private final DockController controller;

  /** the current theme */
  private DockTheme theme;

  /** Listeners observing the ui */
  private final List<UIListener> uiListeners = new ArrayList<>();

  /**
   * a listener that is added to the {@link UIManager} and gets notified when the {@link
   * LookAndFeel} changes
   */
  private final PropertyChangeListener lookAndFeelObserver =
      evt -> {
        if ("lookAndFeel".equals(evt.getPropertyName())) {
          updateUI();
        }
      };

  /** items to transfer directly from {@link DockProperties} to <code>this</code> */
  private final TypedPropertyUIScheme transfers;

  /**
   * Creates a new object
   *
   * @param controller the owner of this manager, not <code>null</code>
   */
  public ThemeManager(DockController controller) {
    super(controller);

    if (controller == null) {
      throw new IllegalArgumentException("controller must not be null");
    }
    this.controller = controller;

    UIManager.addPropertyChangeListener(lookAndFeelObserver);

    transfers = new TypedPropertyUIScheme(controller.getProperties());
    setScheme(Priority.THEME, transfers);
  }

  /** Initializes this manager, must be called exactly once. */
  public void init() {
    registerTypes();
    link();
  }

  private void registerTypes() {
    registerType(STATION_PAINT_TYPE);
    registerType(COMBINER_TYPE);
    registerType(DISPLAYER_FACTORY_TYPE);
    registerType(BACKGROUND_PAINT_TYPE);
    registerType(BORDER_MODIFIER_TYPE);
    registerType(SPAN_FACTORY_TYPE);
  }

  private void link() {
    link(DockTheme.STATION_PAINT, STATION_PAINT_TYPE, STATION_PAINT);
    link(DockTheme.COMBINER, COMBINER_TYPE, COMBINER);
    link(DockTheme.DISPLAYER_FACTORY, DISPLAYER_FACTORY_TYPE, DISPLAYER_FACTORY);
    link(DockTheme.BACKGROUND_PAINT, BACKGROUND_PAINT_TYPE, BACKGROUND_PAINT);
    link(DockTheme.BORDER_MODIFIER, BORDER_MODIFIER_TYPE, BORDER_MODIFIER);
    link(DockTheme.SPAN_FACTORY, SPAN_FACTORY_TYPE, SPAN_FACTORY);
  }

  /** Destroys this manager and releases resources. */
  @FrameworkOnly
  public void kill() {
    theme.uninstall(controller);
    UIManager.removePropertyChangeListener(lookAndFeelObserver);
  }

  /**
   * Creates a link between the property <code>source</code> and the entry <code>id</code> on the
   * level {@link Priority#THEME}.
   *
   * @param <V> the kind of property to read
   * @param <A> the kind of entry to write
   * @param source the key of the property to read
   * @param type the type of the entry to write
   * @param id the identifier of the entry to write
   */
  public <V, A extends V> void link(PropertyKey<A> source, Type<V> type, String id) {
    transfers.link(source, type, id);
  }

  /**
   * Disables a link between a property and the entry <code>id</code>.
   *
   * @param <V> the <code>type</code>
   * @param type the type of the entry
   * @param id the identifier of the entry to unlink
   * @see #link(PropertyKey, TypedUIProperties.Type, String)
   */
  public <V> void unlink(Type<V> type, String id) {
    transfers.unlink(type, id);
  }

  /**
   * Adds an {@link UIListener} to this manager, the listener gets notified when the graphical user
   * interface needs an update because the {@link LookAndFeel} changed.
   *
   * @param listener the new listener
   */
  public void addUIListener(UIListener listener) {
    uiListeners.add(listener);
  }

  /**
   * Removes a listener from this manager.
   *
   * @param listener the listener to remove
   */
  public void removeUIListener(UIListener listener) {
    uiListeners.remove(listener);
  }

  /**
   * Gets all the available {@link UIListener}s.
   *
   * @return the list of listeners
   */
  protected UIListener[] uiListeners() {
    return uiListeners.toArray(new UIListener[0]);
  }

  /**
   * Informs all registered {@link UIListener}s that the user interface needs an update because the
   * {@link LookAndFeel} changed.
   *
   * @see #addUIListener(UIListener)
   * @see #removeUIListener(UIListener)
   */
  public void updateUI() {
    for (UIListener listener : uiListeners()) listener.updateUI(controller);
  }

  /**
   * Gets the current theme
   *
   * @return the theme
   */
  public DockTheme getTheme() {
    return theme;
  }

  /**
   * Sets the theme of this manager. This method fires events on registered {@link UIListener}s and
   * ensures that all {@link DockStation}s receive the update
   *
   * @param theme the new theme
   */
  public void setTheme(DockTheme theme) {
    if (theme == null) throw new IllegalArgumentException("Theme must not be null");

    if (this.theme != theme) {
      for (UIListener listener : uiListeners())
        listener.themeWillChange(controller, this.theme, theme);

      DockRegister register = controller.getRegister();
      DockTheme oldTheme = this.theme;
      Dockable focused = null;
      try {
        register.setStalled(true);
        focused = controller.getFocusedDockable();

        if (this.theme != null) this.theme.uninstall(controller);

        this.theme = theme;

        ExtensionName<DockThemeExtension> name =
            new ExtensionName<>(
                DockThemeExtension.DOCK_THEME_EXTENSION,
                DockThemeExtension.class,
                DockThemeExtension.THEME_PARAMETER,
                theme);
        List<DockThemeExtension> extensions = controller.getExtensions().load(name);

        theme.install(controller, extensions.toArray(new DockThemeExtension[0]));
        controller
            .getDockTitleManager()
            .registerTheme(DockTitleManager.THEME_FACTORY_ID, theme.getTitleFactory(controller));

        // update only those station which are registered to this controller
        for (DockStation station : register.listDockStations()) {
          if (station.getController() == controller) {
            station.updateTheme();
          }
        }
      } finally {
        register.setStalled(false);
      }

      controller.setFocusedDockable(new DefaultFocusRequest(focused, null, true));

      for (UIListener listener : uiListeners()) listener.themeChanged(controller, oldTheme, theme);
    }
  }
}
