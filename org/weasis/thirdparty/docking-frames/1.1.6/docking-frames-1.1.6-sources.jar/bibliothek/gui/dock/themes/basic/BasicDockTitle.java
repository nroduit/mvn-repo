/*
 * Bibliothek - DockingFrames
 * Library built on Java/Swing, allows the user to "drag and drop"
 * panels containing any Swing-Component the developer likes to add.
 *
 * Copyright (C) 2007 Benjamin Sigg
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Benjamin Sigg
 * benjamin_sigg@gmx.ch
 * CH - Switzerland
 */

package bibliothek.gui.dock.themes.basic;

import bibliothek.gui.Dockable;
import bibliothek.gui.dock.themes.color.TitleColor;
import bibliothek.gui.dock.themes.font.TitleFont;
import bibliothek.gui.dock.title.AbstractDockTitle;
import bibliothek.gui.dock.title.DockTitleFactory;
import bibliothek.gui.dock.title.DockTitleRequest;
import bibliothek.gui.dock.title.DockTitleVersion;
import bibliothek.gui.dock.util.color.ColorCodes;
import bibliothek.gui.dock.util.font.DockFont;

import javax.swing.*;
import java.awt.*;

/**
 * The default-title that is used most times in the framework. This title shows an icon, a text,
 * some small buttons and a gradient as background.
 *
 * @author Benjamin Sigg
 */
@ColorCodes({
  "title.active.left",
  "title.inactive.left",
  "title.disabled.left",
  "title.active.right",
  "title.inactive.right",
  "title.disabled.right",
  "title.active.text",
  "title.inactive.text"
})
public class BasicDockTitle extends AbstractDockTitle {
  /** A factory for the {@link BasicDockTitle}. */
  public static final DockTitleFactory FACTORY =
      new DockTitleFactory() {
        public void install(DockTitleRequest request) {
          // ignore
        }

        public void uninstall(DockTitleRequest request) {
          // ignore
        }

        public void request(DockTitleRequest request) {
          request.answer(new BasicDockTitle(request.getTarget(), request.getVersion()));
        }
      };

  /** The left color of the gradient if the title is active */
  private final TitleColor activeLeftColor = new BasicTitleColor("title.active.left");
  /** The left color of the gradient if the title is not active */
  private final TitleColor inactiveLeftColor = new BasicTitleColor("title.inactive.left");
  /** The left color of the gradient if the title is disabled */
  private final TitleColor disabledLeftColor = new BasicTitleColor("title.disabled.left");

  /** The right color of the gradient if the title is active */
  private final TitleColor activeRightColor = new BasicTitleColor("title.active.right");
  /** The right color of the gradient if the title is not active */
  private final TitleColor inactiveRightColor = new BasicTitleColor("title.inactive.right");
  /** The right color of the gradient if the title is disabled */
  private final TitleColor disabledRightColor = new BasicTitleColor("title.disabled.right");

  /** The color of the text if the title is active */
  private final TitleColor activeTextColor = new BasicTitleColor("title.active.text");
  /** The color of the text if the title is not active */
  private final TitleColor inactiveTextColor = new BasicTitleColor("title.inactive.text");

  /** The gradient used to paint this title */
  private GradientPaint gradient;

  /**
   * Creates a new title
   *
   * @param dockable the owner of this title
   * @param origin the version which was used to create this title
   */
  public BasicDockTitle(Dockable dockable, DockTitleVersion origin) {
    this(dockable, origin, true);
  }

  /**
   * Creates a new title
   *
   * @param dockable the owner of this title
   * @param origin the version which was used to create this title
   * @param setDefaultConditionalFonts whether to set the default set of conditional fonts for
   *     {@link DockFont#ID_TITLE_ACTIVE} and {@link DockFont#ID_TITLE_INACTIVE}
   */
  protected BasicDockTitle(
      Dockable dockable, DockTitleVersion origin, boolean setDefaultConditionalFonts) {
    super(dockable, origin);
    setActive(false);

    addColor(activeLeftColor);
    addColor(inactiveLeftColor);
    addColor(disabledLeftColor);
    addColor(activeRightColor);
    addColor(inactiveRightColor);
    addColor(disabledRightColor);
    addColor(activeTextColor);
    addColor(inactiveTextColor);

    if (setDefaultConditionalFonts) {
      addConditionalFont(DockFont.ID_TITLE_ACTIVE, TitleFont.KIND_TITLE_FONT, this::isActive);
      addConditionalFont(DockFont.ID_TITLE_INACTIVE, TitleFont.KIND_TITLE_FONT, () -> !isActive());
    }
  }

  @Override
  @Deprecated
  public void reshape(int x, int y, int w, int h) {
    super.reshape(x, y, w, h);
    gradient = null;
  }

  @Override
  public void validate() {
    gradient = null;
    super.validate();
  }

  @Override
  public void setOrientation(Orientation orientation) {
    gradient = null;
    super.setOrientation(orientation);
  }

  @Override
  protected void paintBackground(Graphics g, JComponent component) {
    Graphics2D g2 = (Graphics2D) g;

    if (gradient == null) {
      if (isDisabled()) {
        gradient = getGradient(disabledLeftColor.value(), disabledRightColor.value(), component);
      } else if (isActive()) {
        gradient = getGradient(activeLeftColor.value(), activeRightColor.value(), component);
      } else {
        gradient = getGradient(inactiveLeftColor.value(), inactiveRightColor.value(), component);
      }
    }

    g2.setPaint(gradient);
    g.fillRect(0, 0, component.getWidth(), component.getHeight());
  }

  /**
   * Gets the gradient which is used to fill the background of <code>component</code>.
   *
   * @param left the first color of the gradient
   * @param right the second color of the gradient
   * @param component the component on which the gradient will be used
   * @return the new gradient
   */
  protected GradientPaint getGradient(Color left, Color right, Component component) {
    GradientPaint gradient;

    if (getOrientation().isHorizontal()) {
      float h = component.getHeight() / 2.0f;
      gradient = new GradientPaint(0, h, left, component.getWidth(), h, right, false);
    } else {
      float w = component.getWidth() / 2.0f;
      gradient = new GradientPaint(w, 0, left, w, component.getHeight(), right, false);
    }

    return gradient;
  }

  /**
   * Changes the identifier that is used for the active left color.
   *
   * @param id the new identifier, not <code>null</code>
   */
  public void setActiveLeftColorId(String id) {
    activeLeftColor.setId(id);
  }

  /**
   * Changes the identifier that is used for the active right color.
   *
   * @param id the new identifier, not <code>null</code>
   */
  public void setActiveRightColorId(String id) {
    activeRightColor.setId(id);
  }

  /**
   * Changes the identifier that is used for the active text color.
   *
   * @param id the new identifier, not <code>null</code>
   */
  public void setActiveTextColorId(String id) {
    activeTextColor.setId(id);
  }

  /**
   * Changes the identifier that is used for the disabled left color.
   *
   * @param id the new identifier, not <code>null</code>
   */
  public void setDisabledLeftColorId(String id) {
    disabledLeftColor.setId(id);
  }

  /**
   * Changes the identifier that is used for the disabled right color.
   *
   * @param id the new identifier, not <code>null</code>
   */
  public void setDisabledRightColorId(String id) {
    disabledRightColor.setId(id);
  }

  /**
   * Changes the identifier that is used for the inactive left color.
   *
   * @param id the new identifier, not <code>null</code>
   */
  public void setInactiveLeftColorId(String id) {
    inactiveLeftColor.setId(id);
  }

  /**
   * Changes the identifier that is used for the inactive right color.
   *
   * @param id the new identifier, not <code>null</code>
   */
  public void setInactiveRightColorId(String id) {
    activeRightColor.setId(id);
  }

  /**
   * Changes the identifier that is used for the inactive text color.
   *
   * @param id the new identifier, not <code>null</code>
   */
  public void setInactiveTextColorId(String id) {
    inactiveTextColor.setId(id);
  }

  @Override
  public void setActive(boolean active) {
    super.setActive(active);
    updateColors();
    updateFonts();
  }

  @Override
  protected void setDisabled(boolean disabled) {
    super.setDisabled(disabled);
    updateColors();
    updateFonts();
  }

  /** Invoked after a color has changed. This method ensures that the gradient is recreated. */
  protected void updateColors() {
    gradient = null;

    if (isActive()) {
      if (activeTextColor != null) {
        setForeground(activeTextColor.value());
      }
    } else {
      if (inactiveTextColor != null) {
        setForeground(inactiveTextColor.value());
      }
    }
    repaint();
  }

  /**
   * A implementation of {@link TitleColor} that calls <code>repaint</code> when the color changes.
   *
   * @author Benjamin Sigg
   */
  private class BasicTitleColor extends TitleColor {
    /**
     * Creates a new color
     *
     * @param id the id of the color
     */
    public BasicTitleColor(String id) {
      super(id, BasicDockTitle.this);
    }

    @Override
    protected void changed(Color oldColor, Color newColor) {
      gradient = null;
      updateColors();
    }
  }
}
