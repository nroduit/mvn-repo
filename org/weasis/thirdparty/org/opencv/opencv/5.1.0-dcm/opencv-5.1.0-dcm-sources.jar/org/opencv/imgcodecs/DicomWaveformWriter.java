//
// This file is auto-generated. Please don't modify it!
//
package org.opencv.imgcodecs;

import java.util.ArrayList;
import java.util.List;
import org.opencv.core.Mat;
import org.opencv.core.MatOfInt;
import org.opencv.utils.Converters;

// C++: class DicomWaveformWriter
/**
 * Streaming encoder of T.261 waveform streams (DICOM Supplement 253): samples are pushed
 * in chunks of any size, each completed frame sequence is encoded and returned as soon as it is
 * available, so the memory needed is one frame sequence of samples plus the encoder state whatever
 * the recording length.
 *
 * Usage: open() with the DicomWaveformParams (DICOM_WF_PARAM_CHANNELS is required;
 * DICOM_WF_PARAM_INTRA_PERIOD sets the frame sequence length), then alternate write() and
 * nextItem() (nextItem() returns false while no frame sequence is complete), and finish() for
 * the last partial sequence plus the end-of-stream packet. The first returned buffer starts with
 * the parameter sets, the last ends with the segment metadata and WSS_END; concatenating all
 * returned buffers gives exactly the stream dicomWaveformWrite() would produce for the same
 * samples, and each buffer is suited to be one DICOM Item of Waveform Data (5400,1010).
 */
public class DicomWaveformWriter {

    protected final long nativeObj;
    protected DicomWaveformWriter(long addr) {
      nativeObj = addr;
      long nativeObjCopy = nativeObj;
 org.opencv.core.CleanableMat.cleaner.register(this, () -> delete(nativeObjCopy));
    }

    public long getNativeObjAddr() { return nativeObj; }

    // internal usage only
    public static DicomWaveformWriter __fromPtr__(long addr) { return new DicomWaveformWriter(addr); }

    //
    // C++:   cv::DicomWaveformWriter::DicomWaveformWriter()
    //

    public DicomWaveformWriter() {
        nativeObj = DicomWaveformWriter_0();
 long nativeObjCopy = nativeObj;
 org.opencv.core.CleanableMat.cleaner.register(this, () -> delete(nativeObjCopy));
    }


    //
    // C++:  bool cv::DicomWaveformWriter::open(vector_int waveformParams)
    //

    /**
     * Starts a stream. Throws cv::Exception on invalid parameters.
     * @param waveformParams automatically generated
     * @return automatically generated
     */
    public boolean open(MatOfInt waveformParams) {
        Mat waveformParams_mat = waveformParams;
        return open_0(nativeObj, waveformParams_mat.nativeObj);
    }


    //
    // C++:  bool cv::DicomWaveformWriter::isOpened()
    //

    public boolean isOpened() {
        return isOpened_0(nativeObj);
    }


    //
    // C++:  void cv::DicomWaveformWriter::close()
    //

    /**
     * Discards the stream without finishing it.
     */
    public void close() {
        close_0(nativeObj);
    }


    //
    // C++:  int cv::DicomWaveformWriter::frameSequenceLength()
    //

    /**
     * Frame sequence length in samples (random-access granularity of the stream).
     * @return automatically generated
     */
    public int frameSequenceLength() {
        return frameSequenceLength_0(nativeObj);
    }


    //
    // C++:  int64 cv::DicomWaveformWriter::samplesWritten()
    //

    /**
     * Samples (per channel) pushed so far.
     * @return automatically generated
     */
    public long samplesWritten() {
        return samplesWritten_0(nativeObj);
    }


    //
    // C++:  int64 cv::DicomWaveformWriter::samplesPending()
    //

    /**
     * Samples (per channel) pushed but not yet encoded.
     * @return automatically generated
     */
    public long samplesPending() {
        return samplesPending_0(nativeObj);
    }


    //
    // C++:  bool cv::DicomWaveformWriter::write(Mat samples)
    //

    /**
     * Appends samples: rows = samples, cols = channels (CV_8S, CV_16S or CV_32S).
     * @param samples automatically generated
     * @return automatically generated
     */
    public boolean write(Mat samples) {
        return write_0(nativeObj, samples.nativeObj);
    }


    //
    // C++:  bool cv::DicomWaveformWriter::nextItem(Mat& packets)
    //

    /**
     * Encodes the next complete frame sequence, if the pending samples hold one.
     *     @param packets the stream packets of that sequence (1 x N CV_8U); the first call also
     * returns the parameter set packets. @return false when fewer than a frame sequence is pending.
     */
    public boolean nextItem(Mat packets) {
        return nextItem_0(nativeObj, packets.nativeObj);
    }


    //
    // C++:  bool cv::DicomWaveformWriter::finish(Mat& packets)
    //

    /**
     * Encodes the remaining samples and terminates the stream.
     *     @param packets the last sequence (if any), the segment metadata and the WSS_END packet.
     * @return false when nothing was written or the stream is already finished.
     */
    public boolean finish(Mat packets) {
        return finish_0(nativeObj, packets.nativeObj);
    }




    // C++:   cv::DicomWaveformWriter::DicomWaveformWriter()
    private static native long DicomWaveformWriter_0();

    // C++:  bool cv::DicomWaveformWriter::open(vector_int waveformParams)
    private static native boolean open_0(long nativeObj, long waveformParams_mat_nativeObj);

    // C++:  bool cv::DicomWaveformWriter::isOpened()
    private static native boolean isOpened_0(long nativeObj);

    // C++:  void cv::DicomWaveformWriter::close()
    private static native void close_0(long nativeObj);

    // C++:  int cv::DicomWaveformWriter::frameSequenceLength()
    private static native int frameSequenceLength_0(long nativeObj);

    // C++:  int64 cv::DicomWaveformWriter::samplesWritten()
    private static native long samplesWritten_0(long nativeObj);

    // C++:  int64 cv::DicomWaveformWriter::samplesPending()
    private static native long samplesPending_0(long nativeObj);

    // C++:  bool cv::DicomWaveformWriter::write(Mat samples)
    private static native boolean write_0(long nativeObj, long samples_nativeObj);

    // C++:  bool cv::DicomWaveformWriter::nextItem(Mat& packets)
    private static native boolean nextItem_0(long nativeObj, long packets_nativeObj);

    // C++:  bool cv::DicomWaveformWriter::finish(Mat& packets)
    private static native boolean finish_0(long nativeObj, long packets_nativeObj);

    // native support for java finalize() or cleaner
    private static native void delete(long nativeObj);

}
