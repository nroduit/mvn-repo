//
// This file is auto-generated. Please don't modify it!
//
package org.opencv.imgcodecs;

import java.util.ArrayList;
import java.util.List;
import org.opencv.core.Mat;
import org.opencv.core.MatOfDouble;
import org.opencv.utils.Converters;

// C++: class DicomWaveformReader
/**
 * Random-access reader of a T.261 Waveform Data Stream (DICOM Supplement 253) that never
 * decodes more than the frame sequences covering a request.
 *
 * On open, the packet headers are walked once (without decoding) to build the index of the frame
 * sequences (independent frame plus its dependent frames); read() then decodes only the sequences
 * overlapping the requested window and keeps the last ones in a small cache, so scrolling through
 * a long recording costs one frame sequence of decoding per jump and a copy otherwise. openFile()
 * reads the DICOM Items lazily from the file, so neither the stream nor the samples are held in
 * memory beyond one packet and the cached sequences.
 */
public class DicomWaveformReader {

    protected final long nativeObj;
    protected DicomWaveformReader(long addr) {
      nativeObj = addr;
      long nativeObjCopy = nativeObj;
 org.opencv.core.CleanableMat.cleaner.register(this, () -> delete(nativeObjCopy));
    }

    public long getNativeObjAddr() { return nativeObj; }

    // internal usage only
    public static DicomWaveformReader __fromPtr__(long addr) { return new DicomWaveformReader(addr); }

    //
    // C++:   cv::DicomWaveformReader::DicomWaveformReader()
    //

    public DicomWaveformReader() {
        nativeObj = DicomWaveformReader_0();
 long nativeObjCopy = nativeObj;
 org.opencv.core.CleanableMat.cleaner.register(this, () -> delete(nativeObjCopy));
    }


    //
    // C++:  bool cv::DicomWaveformReader::open(Mat buf)
    //

    /**
     * Opens a stream held in memory (the concatenated Item values of one multiplex group).
     * The buffer is copied.
     * @param buf automatically generated
     * @return automatically generated
     */
    public boolean open(Mat buf) {
        return open_0(nativeObj, buf.nativeObj);
    }


    //
    // C++:  bool cv::DicomWaveformReader::openFile(String filename, vector_double segposition, vector_double seglength)
    //

    /**
     * Opens a stream stored in a DICOM file as Items.
     *     @param filename the DICOM file.
     *     @param segposition byte position of each Item value in the file.
     * @param seglength byte length of each Item value.
     * @return automatically generated
     */
    public boolean openFile(String filename, MatOfDouble segposition, MatOfDouble seglength) {
        Mat segposition_mat = segposition;
        Mat seglength_mat = seglength;
        return openFile_0(nativeObj, filename, segposition_mat.nativeObj, seglength_mat.nativeObj);
    }


    //
    // C++:  bool cv::DicomWaveformReader::isOpened()
    //

    public boolean isOpened() {
        return isOpened_0(nativeObj);
    }


    //
    // C++:  void cv::DicomWaveformReader::close()
    //

    public void close() {
        close_0(nativeObj);
    }


    //
    // C++:  int cv::DicomWaveformReader::channels()
    //

    public int channels() {
        return channels_0(nativeObj);
    }


    //
    // C++:  int cv::DicomWaveformReader::bitDepth()
    //

    /**
     * Coded bit depth of the stream (4, 8, 12, 16, 20, 24 or 28).
     * @return automatically generated
     */
    public int bitDepth() {
        return bitDepth_0(nativeObj);
    }


    //
    // C++:  double cv::DicomWaveformReader::samplingFrequency()
    //

    /**
     * Sampling frequency carried by the stream, 0 when the encoder did not set it.
     * @return automatically generated
     */
    public double samplingFrequency() {
        return samplingFrequency_0(nativeObj);
    }


    //
    // C++:  int64 cv::DicomWaveformReader::numSamples()
    //

    /**
     * Total number of samples per channel.
     * @return automatically generated
     */
    public long numSamples() {
        return numSamples_0(nativeObj);
    }


    //
    // C++:  int cv::DicomWaveformReader::numFrameSequences()
    //

    /**
     * Number of frame sequences (random-access units).
     * @return automatically generated
     */
    public int numFrameSequences() {
        return numFrameSequences_0(nativeObj);
    }


    //
    // C++:  int64 cv::DicomWaveformReader::frameSequenceStart(int index)
    //

    /**
     * First sample index of a frame sequence.
     * @param index automatically generated
     * @return automatically generated
     */
    public long frameSequenceStart(int index) {
        return frameSequenceStart_0(nativeObj, index);
    }


    //
    // C++:  int cv::DicomWaveformReader::frameSequenceLength(int index)
    //

    /**
     * Number of samples per channel of a frame sequence.
     * @param index automatically generated
     * @return automatically generated
     */
    public int frameSequenceLength(int index) {
        return frameSequenceLength_0(nativeObj, index);
    }


    //
    // C++:  bool cv::DicomWaveformReader::read(int64 startSample, int count, Mat& samples)
    //

    /**
     * Decodes a window of samples.
     *     @param startSample first sample (per channel).
     *     @param count number of samples; clipped at the end of the stream.
     *     @param samples output, rows = samples, cols = channels, CV_16S for streams up to 16 bits, CV_32S above.
     * @return false when the reader is not open, the window is empty, or decoding failed (logged).
     */
    public boolean read(long startSample, int count, Mat samples) {
        return read_0(nativeObj, startSample, count, samples.nativeObj);
    }




    // C++:   cv::DicomWaveformReader::DicomWaveformReader()
    private static native long DicomWaveformReader_0();

    // C++:  bool cv::DicomWaveformReader::open(Mat buf)
    private static native boolean open_0(long nativeObj, long buf_nativeObj);

    // C++:  bool cv::DicomWaveformReader::openFile(String filename, vector_double segposition, vector_double seglength)
    private static native boolean openFile_0(long nativeObj, String filename, long segposition_mat_nativeObj, long seglength_mat_nativeObj);

    // C++:  bool cv::DicomWaveformReader::isOpened()
    private static native boolean isOpened_0(long nativeObj);

    // C++:  void cv::DicomWaveformReader::close()
    private static native void close_0(long nativeObj);

    // C++:  int cv::DicomWaveformReader::channels()
    private static native int channels_0(long nativeObj);

    // C++:  int cv::DicomWaveformReader::bitDepth()
    private static native int bitDepth_0(long nativeObj);

    // C++:  double cv::DicomWaveformReader::samplingFrequency()
    private static native double samplingFrequency_0(long nativeObj);

    // C++:  int64 cv::DicomWaveformReader::numSamples()
    private static native long numSamples_0(long nativeObj);

    // C++:  int cv::DicomWaveformReader::numFrameSequences()
    private static native int numFrameSequences_0(long nativeObj);

    // C++:  int64 cv::DicomWaveformReader::frameSequenceStart(int index)
    private static native long frameSequenceStart_0(long nativeObj, int index);

    // C++:  int cv::DicomWaveformReader::frameSequenceLength(int index)
    private static native int frameSequenceLength_0(long nativeObj, int index);

    // C++:  bool cv::DicomWaveformReader::read(int64 startSample, int count, Mat& samples)
    private static native boolean read_0(long nativeObj, long startSample, int count, long samples_nativeObj);

    // native support for java finalize() or cleaner
    private static native void delete(long nativeObj);

}
