/*
 * Copyright (c) 2009-2026 Nicolas Roduit and other contributors.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.weasis.maven;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.Semaphore;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.tukaani.xz.UnsupportedOptionsException;

/**
 * Compresses the jar files of a directory with xz: each {@code <name>.jar} gives {@code
 * <name>.jar.xz}, an LZMA2 stream of the jar written again without compression (see {@link
 * XzPacker}). The jars are compressed in parallel within a memory budget.
 */
@Mojo(name = "packFiles", defaultPhase = LifecyclePhase.PACKAGE, threadSafe = true)
public class XzCompressionMojo extends AbstractMojo {

  /** The base directory scanned for the files to compress. */
  @Parameter(property = "xz.archiveDirectory", required = true)
  private File archiveDirectory;

  /**
   * The directory where the {@code .xz} files are written, at the same relative path; the archive
   * directory when not given.
   */
  @Parameter(property = "xz.outputDirectory")
  private File outputDirectory;

  /** Ant-like inclusion patterns, relative to the archive directory. */
  @Parameter(defaultValue = "**/*.?ar")
  private String[] includes;

  /** Ant-like exclusion patterns, relative to the archive directory. */
  @Parameter
  private String[] excludes;

  /** The xz preset, from 0 (fastest) to 9 (smallest). */
  @Parameter(property = "xz.compressionLevel", defaultValue = "9")
  private int xzCompressionLevel;

  /** The number of jars compressed at the same time; 0 for the number of processors. */
  @Parameter(property = "xz.threads", defaultValue = "0")
  private int threads;

  /** Skip the goal. */
  @Parameter(property = "xz.skip", defaultValue = "false")
  private boolean skip;

  /** The memory, in KiB, the encoders may use together; 60 % of the heap when 0. */
  long memoryBudgetKiB;

  /** The compressions running now and the most seen at once, for the tests. */
  final java.util.concurrent.atomic.AtomicInteger running = new java.util.concurrent.atomic.AtomicInteger();

  final java.util.concurrent.atomic.AtomicInteger maxRunning =
      new java.util.concurrent.atomic.AtomicInteger();

  /** 60 % of the heap, in KiB. */
  static long defaultBudgetKiB(long maxMemoryBytes) {
    return maxMemoryBytes / 1024 * 6 / 10;
  }

  @Override
  public void execute() throws MojoExecutionException {
    if (skip) {
      getLog().info("xz compression skipped");
      return;
    }
    if (archiveDirectory == null) {
      throw new MojoExecutionException("archiveDirectory is not set");
    }
    if (xzCompressionLevel < 0 || xzCompressionLevel > 9) {
      throw new MojoExecutionException(
          "xzCompressionLevel must be within 0 and 9: " + xzCompressionLevel);
    }
    Path base = archiveDirectory.toPath();
    Path output = outputDirectory == null ? base : outputDirectory.toPath();
    List<Path> files;
    try {
      files = new AntPatterns(includes, excludes).scan(base);
    } catch (IOException e) {
      throw new MojoExecutionException("Cannot scan " + base + ": " + e.getMessage(), e);
    }
    if (files.isEmpty()) {
      getLog().info("No file to compress in " + base);
      return;
    }

    int workers = threads > 0 ? threads : Runtime.getRuntime().availableProcessors();
    long budget =
        memoryBudgetKiB > 0 ? memoryBudgetKiB : defaultBudgetKiB(Runtime.getRuntime().maxMemory());
    int permits = (int) Math.min(Integer.MAX_VALUE, Math.max(1, budget));
    Semaphore memory = new Semaphore(permits);
    Path work = output.resolve(".xz-work");
    List<XzPacker.Result> results = new ArrayList<>();
    try (ExecutorService pool = Executors.newFixedThreadPool(Math.min(workers, files.size()))) {
      List<Future<XzPacker.Result>> tasks = new ArrayList<>();
      for (Path jar : files) {
        Path xz = output.resolve(AntPatterns.relative(base, jar) + ".xz");
        tasks.add(pool.submit(() -> compress(jar, xz, work, memory, permits)));
      }
      for (Future<XzPacker.Result> t : tasks) {
        results.add(t.get());
      }
    } catch (ExecutionException e) {
      Throwable c = e.getCause();
      throw new MojoExecutionException("xz compression failed: " + c.getMessage(), c);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new MojoExecutionException("Interrupted", e);
    } finally {
      try {
        Files.deleteIfExists(work);
      } catch (IOException e) {
        getLog().debug("Cannot delete " + work + ": " + e);
      }
    }
    long jars = results.stream().mapToLong(XzPacker.Result::jarSize).sum();
    long xzs = results.stream().mapToLong(XzPacker.Result::xzSize).sum();
    getLog()
        .info(
            "Compressed %d file(s) with xz -%d: %,d bytes -> %,d bytes (%d %%)"
                .formatted(
                    results.size(),
                    xzCompressionLevel,
                    jars,
                    xzs,
                    jars == 0 ? 0 : xzs * 100 / jars));
  }

  private XzPacker.Result compress(Path jar, Path xz, Path work, Semaphore memory, int permits)
      throws IOException, InterruptedException {
    int need = Math.min(permits, encoderMemory(xzCompressionLevel, Files.size(jar)));
    memory.acquire(need);
    maxRunning.accumulateAndGet(running.incrementAndGet(), Math::max);
    try {
      XzPacker.Result r =
          XzPacker.pack(jar, xz, xzCompressionLevel, work, m -> getLog().warn(m));
      getLog().debug("%s: %,d -> %,d bytes".formatted(xz.getFileName(), r.jarSize(), r.xzSize()));
      return r;
    } catch (IOException e) {
      throw new IOException(jar + ": " + e.getMessage(), e);
    } finally {
      running.decrementAndGet();
      memory.release(need);
    }
  }

  /** The encoder memory for a jar: the stored zip is at most a few times the jar, take 4×. */
  static int encoderMemory(int level, long jarSize) throws UnsupportedOptionsException {
    return XzPacker.encoderMemoryKiB(level, jarSize * 4);
  }
}
