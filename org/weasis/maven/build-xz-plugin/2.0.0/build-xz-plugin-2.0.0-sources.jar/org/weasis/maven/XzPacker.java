/*
 * Copyright (c) 2009-2026 Nicolas Roduit and other contributors.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.weasis.maven;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Consumer;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import org.tukaani.xz.LZMA2Options;
import org.tukaani.xz.UnsupportedOptionsException;
import org.tukaani.xz.XZOutputStream;

/**
 * Compresses a jar into {@code <jar>.xz}: the entries are first written again without compression
 * (a stored zip, still a valid jar once decompressed), so that xz compresses the content itself
 * rather than already deflated data, then the stored zip is compressed with LZMA2.
 *
 * <p>The entries keep their order (the manifest stays first, as {@link java.util.jar.JarInputStream}
 * needs), their time and their comment, so the same jar gives the same {@code .xz}. Nothing is
 * extracted to the disk.
 */
public final class XzPacker {

  /** The sizes of one compression. */
  public record Result(long jarSize, long storedSize, long xzSize) {}

  private XzPacker() {}

  /**
   * The LZMA2 options of a preset, with the dictionary not larger than the input: the output is as
   * good and the encoder needs far less memory for a small jar (preset 9 is 64 MiB of dictionary).
   */
  public static LZMA2Options options(int preset, long inputSize) throws UnsupportedOptionsException {
    LZMA2Options options = new LZMA2Options(preset);
    long dict = Math.max(LZMA2Options.DICT_SIZE_MIN, inputSize);
    if (dict < options.getDictSize()) {
      options.setDictSize((int) dict);
    }
    return options;
  }

  /** Memory, in KiB, the encoder of a preset needs for an input of this size. */
  public static int encoderMemoryKiB(int preset, long inputSize) throws UnsupportedOptionsException {
    return options(preset, inputSize).getEncoderMemoryUsage();
  }

  /**
   * Compresses the jar into the xz file, through a stored zip written in {@code workDir}.
   *
   * @param warn receives a message for a duplicate entry, which is skipped
   */
  public static Result pack(Path jar, Path xz, int preset, Path workDir, Consumer<String> warn)
      throws IOException {
    Files.createDirectories(workDir);
    Path stored = Files.createTempFile(workDir, "xz-", ".zip");
    try {
      long storedSize = writeStored(jar, stored, warn);
      Path parent = xz.toAbsolutePath().getParent();
      if (parent != null) {
        Files.createDirectories(parent);
      }
      Path tmp = Files.createTempFile(parent, "xz-", ".part");
      try {
        try (InputStream in = Files.newInputStream(stored);
            XZOutputStream out =
                new XZOutputStream(
                    new BufferedOutputStream(Files.newOutputStream(tmp)), options(preset, storedSize))) {
          in.transferTo(out);
        }
        Files.move(tmp, xz, StandardCopyOption.REPLACE_EXISTING);
      } finally {
        Files.deleteIfExists(tmp);
      }
      return new Result(Files.size(jar), storedSize, Files.size(xz));
    } finally {
      Files.deleteIfExists(stored);
    }
  }

  /** Writes the entries of the jar again, uncompressed and in the same order; returns its size. */
  static long writeStored(Path jar, Path stored, Consumer<String> warn) throws IOException {
    try (ZipFile zip = new ZipFile(jar.toFile());
        OutputStream file = new BufferedOutputStream(Files.newOutputStream(stored));
        ZipOutputStream out = new ZipOutputStream(file)) {
      out.setMethod(ZipOutputStream.STORED);
      if (zip.getComment() != null) {
        out.setComment(zip.getComment());
      }
      Set<String> names = new HashSet<>();
      Enumeration<? extends ZipEntry> entries = zip.entries();
      while (entries.hasMoreElements()) {
        ZipEntry e = entries.nextElement();
        if (!names.add(e.getName())) {
          warn.accept(jar.getFileName() + ": duplicate entry " + e.getName() + " skipped");
          continue;
        }
        byte[] data;
        try (InputStream in = zip.getInputStream(e)) {
          data = in.readAllBytes();
        }
        CRC32 crc = new CRC32();
        crc.update(data);
        // STORED (the method of the stream): the size and the CRC are written before the data
        ZipEntry s = new ZipEntry(e.getName());
        s.setSize(data.length);
        s.setCrc(crc.getValue());
        s.setTime(e.getTime());
        if (e.getComment() != null) {
          s.setComment(e.getComment());
        }
        out.putNextEntry(s);
        out.write(data);
      }
    }
    return Files.size(stored);
  }
}
