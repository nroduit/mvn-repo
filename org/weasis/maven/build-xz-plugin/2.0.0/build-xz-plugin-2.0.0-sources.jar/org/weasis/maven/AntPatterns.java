/*
 * Copyright (c) 2009-2026 Nicolas Roduit and other contributors.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.weasis.maven;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Ant-like inclusion and exclusion patterns on paths relative to a base directory, with '/' as
 * separator on every platform: {@code *} matches within one directory, {@code ?} one character,
 * {@code **} any number of directories (also none: {@code **}{@code /*.jar} matches {@code a.jar}),
 * and a pattern ending with '/' matches everything under that directory. A pattern can hold several
 * comma-separated patterns.
 */
public final class AntPatterns {

  private final List<Pattern> includes;
  private final List<Pattern> excludes;

  public AntPatterns(String[] includes, String[] excludes) {
    this.includes = compile(includes);
    this.excludes = compile(excludes);
  }

  private static List<Pattern> compile(String[] patterns) {
    List<Pattern> list = new ArrayList<>();
    if (patterns != null) {
      for (String p : patterns) {
        if (p == null) {
          continue;
        }
        for (String one : p.split(",")) {
          String s = one.strip().replace('\\', '/');
          if (!s.isEmpty()) {
            list.add(toRegex(s));
          }
        }
      }
    }
    return list;
  }

  static Pattern toRegex(String pattern) {
    String p = pattern.startsWith("/") ? pattern.substring(1) : pattern;
    if (p.endsWith("/")) {
      p = p + "**";
    }
    StringBuilder re = new StringBuilder();
    for (int i = 0; i < p.length(); i++) {
      char c = p.charAt(i);
      if (c == '*') {
        boolean twice = i + 1 < p.length() && p.charAt(i + 1) == '*';
        if (twice) {
          boolean slash = i + 2 < p.length() && p.charAt(i + 2) == '/';
          re.append(slash ? "(?:.*/)?" : ".*");
          i += slash ? 2 : 1;
        } else {
          re.append("[^/]*");
        }
      } else if (c == '?') {
        re.append("[^/]");
      } else {
        re.append(Pattern.quote(String.valueOf(c)));
      }
    }
    return Pattern.compile(re.toString());
  }

  /** True when the relative path (with '/') is included and not excluded. */
  public boolean matches(String relativePath) {
    String path = relativePath.replace('\\', '/');
    return includes.stream().anyMatch(p -> p.matcher(path).matches())
        && excludes.stream().noneMatch(p -> p.matcher(path).matches());
  }

  /** The regular files under the directory that match, sorted by relative path. */
  public List<Path> scan(Path directory) throws IOException {
    if (!Files.isDirectory(directory)) {
      return List.of();
    }
    try (Stream<Path> files = Files.walk(directory)) {
      return files
          .filter(Files::isRegularFile)
          .filter(f -> matches(relative(directory, f)))
          .sorted()
          .toList();
    } catch (UncheckedIOException e) {
      // Files.walk reports an unreadable directory met during the walk unchecked
      throw e.getCause();
    }
  }

  static String relative(Path base, Path file) {
    return base.relativize(file).toString().replace('\\', '/');
  }
}
