/*
 * Copyright (c) 2009-2026 Nicolas Roduit and other contributors.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.weasis.maven;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.Semaphore;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.weasis.maven.TransifexClient.LanguageStats;

/**
 * Downloads the translations of Transifex resources and writes them as the {@code
 * <baseName>_<lang>.properties} files of a language pack.
 *
 * <p>A language whose file holds no translation is not written. With {@code buildLanguagesFile},
 * the written languages and their completion (translated and reviewed, over all the resources of
 * the project) are recorded as {@code languages}, {@code percentages} and {@code reviewed}.
 */
@Mojo(name = "buildLanguagePacks", defaultPhase = LifecyclePhase.PROCESS_RESOURCES, threadSafe = true)
public class BuildLanguagePacksMojo extends AbstractMojo {

  /** Base URL of the Transifex REST API. */
  @Parameter(
      property = "transifex.baseURL",
      defaultValue = "https://rest.api.transifex.com/",
      required = true)
  private String baseURL;

  /** The organization slug. */
  @Parameter(property = "transifex.organization", required = true)
  private String organization;

  /** The project slug. */
  @Parameter(property = "transifex.project", required = true)
  private String project;

  /**
   * API token, generated at https://app.transifex.com/user/settings/api/. Checked when the goal
   * runs, so that {@code transifex.skip} works without one.
   */
  @Parameter(property = "transifex.token")
  private String token;

  /** The directory where the files are written. */
  @Parameter(property = "transifex.outputDirectory", required = true)
  private File outputDirectory;

  /** The Transifex resources (slugs). */
  @Parameter(property = "transifex.modules", required = true)
  private String[] modules;

  /** The base name of the files of each resource, {@code messages} when not given. */
  @Parameter(property = "transifex.baseNames")
  private String[] baseNames;

  /** The file receiving the languages and their completion. */
  @Parameter(property = "transifex.buildLanguagesFile")
  private File buildLanguagesFile;

  /**
   * The Transifex download mode. {@code onlytranslated} (default) gives the translated strings
   * only, so that Weasis shows its own English text for the others; {@code onlyreviewed} gives the
   * reviewed ones only; {@code default} fills the untranslated strings with the source text of
   * Transifex, which can be older than the English of the application.
   */
  @Parameter(property = "transifex.mode", defaultValue = "onlytranslated")
  private String mode;

  /**
   * The encoding of the written files: {@code UTF-8} (default, read by Java 9 and later) or {@code
   * ISO-8859-1} (characters above U+00FF written as escapes).
   */
  @Parameter(property = "transifex.outputEncoding", defaultValue = "UTF-8")
  private String outputEncoding;

  /** Skip a resource that does not exist in the project instead of failing the build. */
  @Parameter(property = "transifex.skipMissingResources", defaultValue = "false")
  private boolean skipMissingResources;

  /** The number of downloads run at the same time. */
  @Parameter(property = "transifex.parallelDownloads", defaultValue = "8")
  private int parallelDownloads;

  /** The time, in seconds, Transifex may take to prepare one file. */
  @Parameter(property = "transifex.downloadTimeout", defaultValue = "300")
  private int downloadTimeout;

  /** Skip the goal. */
  @Parameter(property = "transifex.skip", defaultValue = "false")
  private boolean skip;

  /** The waits of the client between attempts, replaced by the tests; null for real sleeps. */
  TransifexClient.Sleeper sleeper;

  @Override
  public void execute() throws MojoExecutionException {
    if (skip) {
      getLog().info("Transifex download skipped");
      return;
    }
    if (token == null || token.isBlank()) {
      throw new MojoExecutionException("No Transifex token: set -Dtransifex.token=<token>");
    }
    Charset charset;
    try {
      charset = Charset.forName(outputEncoding);
    } catch (IllegalArgumentException e) {
      throw new MojoExecutionException("Unknown outputEncoding " + outputEncoding, e);
    }
    TransifexClient client =
        new TransifexClient(
            baseURL,
            organization,
            project,
            token,
            Duration.ofSeconds(downloadTimeout),
            m -> getLog().debug(m));
    if (sleeper != null) {
      client.sleeper(sleeper);
    }
    try {
      Files.createDirectories(outputDirectory.toPath());
      List<String> languages = client.languages();
      getLog().info("%s: %d languages".formatted(client.projectId(), languages.size()));
      Set<String> written = new TreeSet<>();
      for (int i = 0; i < modules.length; i++) {
        String baseName =
            baseNames != null && baseNames.length > i && baseNames[i] != null
                ? baseNames[i]
                : "messages";
        written.addAll(downloadResource(client, modules[i], baseName, languages, charset));
      }
      if (buildLanguagesFile != null) {
        writeLanguagesFile(client.languageStats(), written);
      }
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new MojoExecutionException("Interrupted", e);
    } catch (IOException e) {
      throw new MojoExecutionException("Transifex: " + e.getMessage(), e);
    }
  }

  /** Downloads one resource in every language; returns the language codes written. */
  private Set<String> downloadResource(
      TransifexClient client, String resource, String baseName, List<String> languages, Charset charset)
      throws IOException, InterruptedException, MojoExecutionException {
    if (!client.resourceExists(resource)) {
      String msg = "Resource %s does not exist in %s".formatted(resource, client.projectId());
      if (skipMissingResources) {
        getLog().warn(msg + ", skipped");
        return Set.of();
      }
      throw new MojoExecutionException(msg);
    }
    Map<String, String> failures = new ConcurrentSkipListMap<>();
    Set<String> written = new TreeSet<>();
    Semaphore slots = new Semaphore(Math.max(1, parallelDownloads));
    try (ExecutorService pool = Executors.newVirtualThreadPerTaskExecutor()) {
      List<Future<String>> tasks = new ArrayList<>();
      for (String languageId : languages) {
        tasks.add(
            pool.submit(
                () -> {
                  slots.acquire();
                  try {
                    return downloadOne(client, resource, baseName, languageId, charset);
                  } catch (IOException e) {
                    failures.put(languageId, e.getMessage());
                    return null;
                  } finally {
                    slots.release();
                  }
                }));
      }
      for (Future<String> t : tasks) {
        try {
          String code = t.get();
          if (code != null) {
            written.add(code);
          }
        } catch (java.util.concurrent.ExecutionException e) {
          throw new MojoExecutionException("Download of " + resource + " failed", e.getCause());
        }
      }
    }
    if (!failures.isEmpty()) {
      failures.forEach((l, m) -> getLog().error(l + ": " + m));
      throw new MojoExecutionException(
          "%s: %d language(s) not downloaded %s".formatted(resource, failures.size(), failures.keySet()));
    }
    getLog().info("%s: %d language file(s) written".formatted(resource, written.size()));
    return written;
  }

  /** Downloads and writes one file; returns its language code, or null when it has no translation. */
  private String downloadOne(
      TransifexClient client, String resource, String baseName, String languageId, Charset charset)
      throws IOException, InterruptedException {
    byte[] bytes = client.downloadTranslation(resource, languageId, mode);
    PropertiesConverter.Result result = PropertiesConverter.convert(bytes, charset);
    String code = languageCode(languageId);
    Path file = outputDirectory.toPath().resolve("%s_%s.properties".formatted(baseName, code));
    if (result.isEmpty()) {
      Files.deleteIfExists(file);
      getLog().debug(resource + " " + code + ": no translation");
      return null;
    }
    Files.writeString(file, result.content(), charset);
    getLog().debug(resource + " " + code + ": " + result.entries() + " entries");
    return code;
  }

  /** {@code l:pt_BR} → {@code pt_BR}, {@code l:sr-Latn} → {@code sr_Latn}. */
  static String languageCode(String languageId) {
    String code = languageId.startsWith("l:") ? languageId.substring(2) : languageId;
    return code.replace('-', '_');
  }

  private void writeLanguagesFile(Map<String, LanguageStats> stats, Set<String> written)
      throws IOException {
    Map<String, LanguageStats> byCode = new java.util.HashMap<>();
    stats.forEach((id, s) -> byCode.put(languageCode(id), s));
    StringBuilder languages = new StringBuilder("en");
    StringBuilder percentages = new StringBuilder("en.100");
    StringBuilder reviewed = new StringBuilder("en.100");
    for (String code : written) {
      LanguageStats s = byCode.getOrDefault(code, new LanguageStats(0, 0, 0));
      languages.append(',').append(code);
      percentages.append(',').append(code).append('.').append(s.translatedPercent());
      reviewed.append(',').append(code).append('.').append(s.reviewedPercent());
    }
    getLog().info("languages: " + languages);
    Path file = buildLanguagesFile.toPath();
    if (file.getParent() != null) {
      Files.createDirectories(file.getParent());
    }
    Files.writeString(
        file,
        "languages=" + languages + "\npercentages=" + percentages + "\nreviewed=" + reviewed + "\n",
        java.nio.charset.StandardCharsets.ISO_8859_1);
  }
}
