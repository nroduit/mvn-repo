/*
 * Copyright (c) 2009-2026 Nicolas Roduit and other contributors.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.weasis.maven;

import java.io.IOException;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandler;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * The calls of the Transifex REST API v3 used to build the language packs: the languages of a
 * project, the asynchronous download of a resource translation, the statistics per language.
 *
 * <p>Every call is retried on HTTP 429 and 5xx and on an I/O error, waiting for {@code Retry-After}
 * when the server gives it. The client is safe to share between threads.
 */
public class TransifexClient {

  /** The completion of a language over all the resources of the project. */
  public record LanguageStats(long total, long translated, long reviewed) {
    public int translatedPercent() {
      return percent(translated);
    }

    public int reviewedPercent() {
      return percent(reviewed);
    }

    private int percent(long n) {
      return total == 0 ? 0 : (int) (n * 100 / total);
    }
  }

  /** A call that failed after its retries, with the status and the body of the last answer. */
  public static class TransifexException extends IOException {
    private final int status;

    public TransifexException(String message, int status) {
      super(message);
      this.status = status;
    }

    public int status() {
      return status;
    }
  }

  /** Waits between two attempts; replaced by the tests so that they do not sleep. */
  @FunctionalInterface
  interface Sleeper {
    void sleep(Duration d) throws InterruptedException;
  }

  private static final String JSON_API = "application/vnd.api+json";
  static final int MAX_ATTEMPTS = 6;
  static final Duration MAX_RETRY_WAIT = Duration.ofSeconds(60);

  private final URI base;
  private final String organization;
  private final String project;
  private final String token;
  private final Duration downloadTimeout;
  private final HttpClient http;
  private final Consumer<String> debug;
  private Sleeper sleeper = Thread::sleep;

  public TransifexClient(
      String baseURL,
      String organization,
      String project,
      String token,
      Duration downloadTimeout,
      Consumer<String> debug) {
    this.base = URI.create(baseURL.endsWith("/") ? baseURL : baseURL + "/");
    this.organization = organization;
    this.project = project;
    this.token = token;
    this.downloadTimeout = downloadTimeout;
    this.debug = debug;
    // No redirect: the end of an asynchronous download is a 303 whose location is the file.
    // The default proxy selector reads http(s).proxyHost; http(s).proxyUser and proxyPassword
    // authenticate on it.
    HttpClient.Builder builder =
        HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.NEVER)
            .connectTimeout(Duration.ofSeconds(30));
    String user = System.getProperty("https.proxyUser", System.getProperty("http.proxyUser"));
    String password =
        System.getProperty("https.proxyPassword", System.getProperty("http.proxyPassword"));
    if (user != null && password != null) {
        builder.authenticator(proxyAuthenticator(user, password));
    }
    this.http = builder.build();
  }

  /** Answers the proxy only, never the server: the API is authenticated by the token. */
  static Authenticator proxyAuthenticator(String user, String password) {
    return new Authenticator() {
      @Override
      protected PasswordAuthentication getPasswordAuthentication() {
        return getRequestorType() == RequestorType.PROXY
            ? new PasswordAuthentication(user, password.toCharArray())
            : null;
      }
    };
  }

  /** The underlying client, for the tests. */
  HttpClient http() {
    return http;
  }

  TransifexClient sleeper(Sleeper sleeper) {
    this.sleeper = sleeper;
    return this;
  }

  public String projectId() {
    return "o:%s:p:%s".formatted(organization, project);
  }

  public String resourceId(String resource) {
    return projectId() + ":r:" + resource;
  }

  /** The language ids of the project ({@code l:fr}, {@code l:pt_BR}...), in the order of the API. */
  public List<String> languages() throws IOException, InterruptedException {
    List<String> ids = new ArrayList<>();
    for (JSONObject item : getAll("projects/" + projectId() + "/languages")) {
      ids.add(item.getString("id"));
    }
    return ids;
  }

  /** True when the resource exists in the project. */
  public boolean resourceExists(String resource) throws IOException, InterruptedException {
    HttpResponse<String> r = send(get(base.resolve("resources/" + resourceId(resource))));
    if (r.statusCode() == 404) {
      return false;
    }
    check(r, "resource " + resource);
    return true;
  }

  /**
   * Downloads the translation of a resource in a language.
   *
   * @param mode the Transifex download mode ({@code default}, {@code onlytranslated}, {@code
   *     onlyreviewed}...)
   */
  public byte[] downloadTranslation(String resource, String languageId, String mode)
      throws IOException, InterruptedException {
    String payload =
        """
        {
          "data": {
            "attributes": {
              "callback_url": null,
              "content_encoding": "text",
              "file_type": "default",
              "mode": "%s",
              "pseudo": false
            },
            "relationships": {
              "language": { "data": { "id": "%s", "type": "languages" } },
              "resource": { "data": { "id": "%s", "type": "resources" } }
            },
            "type": "resource_translations_async_downloads"
          }
        }"""
            .formatted(mode, languageId, resourceId(resource));
    HttpResponse<String> started =
        send(
            request(base.resolve("resource_translations_async_downloads"))
                .header("Content-Type", JSON_API)
                .POST(BodyPublishers.ofString(payload))
                .build());
    check(started, "download of " + resource + " in " + languageId);
    String id = new JSONObject(started.body()).getJSONObject("data").getString("id");
    URI status = base.resolve("resource_translations_async_downloads/" + id);

    Instant deadline = Instant.now().plus(downloadTimeout);
    long wait = 250;
    while (true) {
      HttpResponse<String> r = send(get(status));
      if (r.statusCode() == 303) {
        String location =
            r.headers()
                .firstValue("location")
                .orElseThrow(() -> new TransifexException("303 without location", 303));
        HttpResponse<byte[]> file =
            send(get(URI.create(location)), BodyHandlers.ofByteArray());
        check(file, "file of " + resource + " in " + languageId);
        return file.body();
      }
      check(r, "status of the download of " + resource + " in " + languageId);
      JSONObject attributes = new JSONObject(r.body()).getJSONObject("data").getJSONObject("attributes");
      String state = attributes.optString("status");
      if ("failed".equals(state)) {
        throw new TransifexException(
            "Transifex failed to build " + resource + " in " + languageId + ": " + attributes.opt("errors"),
            r.statusCode());
      }
      if (Instant.now().isAfter(deadline)) {
        throw new TransifexException(
            "No file after " + downloadTimeout.toSeconds() + " s for " + resource + " in " + languageId
                + " (status " + state + ")",
            r.statusCode());
      }
      sleeper.sleep(Duration.ofMillis(wait));
      wait = Math.min(wait * 2, 2000);
    }
  }

  /** The statistics of every language over all the resources of the project, by language id. */
  public Map<String, LanguageStats> languageStats() throws IOException, InterruptedException {
    Map<String, long[]> sums = new LinkedHashMap<>();
    String path =
        "resource_language_stats?filter%5Bproject%5D="
            + URLEncoder.encode(projectId(), StandardCharsets.UTF_8);
    for (JSONObject item : getAll(path)) {
      String language =
          item.getJSONObject("relationships")
              .getJSONObject("language")
              .getJSONObject("data")
              .getString("id");
      JSONObject a = item.getJSONObject("attributes");
      long translated = a.optLong("translated_strings");
      long untranslated = a.optLong("untranslated_strings");
      long total = a.optLong("total_strings", translated + untranslated);
      long[] s = sums.computeIfAbsent(language, k -> new long[3]);
      s[0] += total;
      s[1] += translated;
      s[2] += a.optLong("reviewed_strings");
    }
    Map<String, LanguageStats> stats = new LinkedHashMap<>();
    sums.forEach((k, s) -> stats.put(k, new LanguageStats(s[0], s[1], s[2])));
    return stats;
  }

  /** The items of a list endpoint, following the {@code links.next} pages. */
  List<JSONObject> getAll(String path) throws IOException, InterruptedException {
    List<JSONObject> items = new ArrayList<>();
    URI next = base.resolve(path);
    while (next != null) {
      HttpResponse<String> r = send(get(next));
      check(r, next.toString());
      JSONObject body = new JSONObject(r.body());
      JSONArray data = body.getJSONArray("data");
      for (int i = 0; i < data.length(); i++) {
        items.add(data.getJSONObject(i));
      }
      JSONObject links = body.optJSONObject("links");
      String n = links == null ? null : links.optString("next", null);
      next = n == null || n.isBlank() || "null".equals(n) ? null : base.resolve(n);
    }
    return items;
  }

  private HttpRequest.Builder request(URI uri) {
    return HttpRequest.newBuilder(uri)
        .timeout(Duration.ofMinutes(2))
        .header("Authorization", "Bearer " + token)
        .header("Accept", JSON_API);
  }

  private HttpRequest get(URI uri) {
    return request(uri).GET().build();
  }

  private HttpResponse<String> send(HttpRequest request) throws IOException, InterruptedException {
    return send(request, BodyHandlers.ofString(StandardCharsets.UTF_8));
  }

  /** Sends the request, retrying on 429, 5xx and I/O errors; any other answer is returned. */
  private <T> HttpResponse<T> send(HttpRequest request, BodyHandler<T> handler)
      throws IOException, InterruptedException {
    IOException last = null;
    for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      try {
        HttpResponse<T> r = http.send(request, handler);
        int code = r.statusCode();
        if (code != 429 && code < 500) {
          return r;
        }
        long seconds =
            r.headers().firstValue("Retry-After").map(TransifexClient::seconds).orElse(1L << attempt);
        debug.accept(request.uri() + " answered " + code + ", retry in " + seconds + " s");
        if (attempt == MAX_ATTEMPTS) {
          return r;
        }
        sleeper.sleep(min(Duration.ofSeconds(seconds), MAX_RETRY_WAIT));
      } catch (IOException e) {
        last = e;
        debug.accept(request.uri() + " failed (" + e + "), attempt " + attempt);
        if (attempt < MAX_ATTEMPTS) {
          sleeper.sleep(min(Duration.ofSeconds(1L << attempt), MAX_RETRY_WAIT));
        }
      }
    }
    throw last;
  }

  private static Duration min(Duration a, Duration b) {
    return a.compareTo(b) <= 0 ? a : b;
  }

  static long seconds(String retryAfter) {
    try {
      return Math.max(1, Long.parseLong(retryAfter.trim()));
    } catch (NumberFormatException e) {
      return 5;
    }
  }

  private static void check(HttpResponse<?> r, String what) throws TransifexException {
    int code = r.statusCode();
    if (code >= 200 && code < 300) {
      return;
    }
    Object body = r.body();
    String text = body instanceof byte[] b ? new String(b, StandardCharsets.UTF_8) : String.valueOf(body);
    if (text.length() > 500) {
      text = text.substring(0, 500) + "…";
    }
    throw new TransifexException(what + ": HTTP " + code + " " + text, code);
  }
}
