/*
 * Copyright (c) 2009-2026 Nicolas Roduit and other contributors.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.weasis.maven;

import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Turns a Java properties file downloaded from Transifex into the file packaged for Weasis.
 *
 * <ul>
 *   <li>The input is read as UTF-8 when it is valid UTF-8 (a {@code UNICODEPROPERTIES} resource),
 *       as ISO-8859-1 otherwise (a {@code PROPERTIES} resource), as {@link
 *       java.util.PropertyResourceBundle} does.
 *   <li>Comments and blank lines are removed, and so is an entry with an empty value: in the {@code
 *       onlytranslated} and {@code onlyreviewed} modes Transifex leaves the untranslated strings
 *       empty, and an empty value would hide the English text of Weasis.
 *   <li>A doubled backslash written by Transifex is reduced to one (behavior kept from the 1.x
 *       versions of the plugin).
 *   <li>In UTF-8 the {@code \\uXXXX} escapes of visible non-ASCII characters are written as the
 *       characters themselves; in ISO-8859-1 the characters above U+00FF are written as escapes.
 * </ul>
 */
public final class PropertiesConverter {

  /** The converted file and the number of entries it holds. */
  public record Result(String content, int entries) {
    public boolean isEmpty() {
      return entries == 0;
    }
  }

  private PropertiesConverter() {}

  /** The charset of the downloaded bytes: UTF-8 when they decode as UTF-8, ISO-8859-1 otherwise. */
  public static Charset detect(byte[] bytes) {
    try {
      StandardCharsets.UTF_8
          .newDecoder()
          .onMalformedInput(CodingErrorAction.REPORT)
          .onUnmappableCharacter(CodingErrorAction.REPORT)
          .decode(ByteBuffer.wrap(bytes));
      return StandardCharsets.UTF_8;
    } catch (CharacterCodingException e) {
      return StandardCharsets.ISO_8859_1;
    }
  }

  public static Result convert(byte[] bytes, Charset output) {
    String text = new String(bytes, detect(bytes));
    if (!text.isEmpty() && text.charAt(0) == '﻿') {
      text = text.substring(1);
    }
    boolean utf8 = StandardCharsets.UTF_8.equals(output);
    StringBuilder out = new StringBuilder(text.length());
    int entries = 0;
    for (List<String> entry : logicalLines(text.split("\r\n|\r|\n", -1))) {
      String first = entry.getFirst().stripLeading();
      if (first.isEmpty() || first.charAt(0) == '#' || first.charAt(0) == '!') {
        continue;
      }
      List<String> lines = new ArrayList<>(entry.size());
      for (String line : entry) {
        lines.add(undoubleBackslashes(line));
      }
      if (!hasValue(String.join("", lines))) {
        continue;
      }
      for (String line : lines) {
        out.append(utf8 ? unescapeVisible(line) : escapeAboveLatin1(line)).append('\n');
      }
      entries++;
    }
    return new Result(out.toString(), entries);
  }

  /** Groups the physical lines into entries: a line ending with an odd number of '\' continues. */
  static List<List<String>> logicalLines(String[] physical) {
    List<List<String>> entries = new ArrayList<>();
    List<String> current = null;
    for (String line : physical) {
      if (current == null) {
        current = new ArrayList<>();
      }
      current.add(line);
      String stripped = line.stripLeading();
      boolean comment =
          current.size() == 1
              && !stripped.isEmpty()
              && (stripped.charAt(0) == '#' || stripped.charAt(0) == '!');
      if (comment || !continues(line)) {
        entries.add(current);
        current = null;
      }
    }
    if (current != null) {
      entries.add(current);
    }
    return entries;
  }

  private static boolean continues(String line) {
    int n = 0;
    for (int i = line.length() - 1; i >= 0 && line.charAt(i) == '\\'; i--) {
      n++;
    }
    return n % 2 == 1;
  }

  static String undoubleBackslashes(String line) {
    return line.replace("\\\\", "\\");
  }

  /**
   * True when the entry has a non-empty value. The key ends at the first unescaped '=', ':' or
   * whitespace; the separator and the whitespace around it are not part of the value.
   */
  static boolean hasValue(String entry) {
    String s = entry.stripLeading();
    int i = 0;
    while (i < s.length()) {
      char c = s.charAt(i);
      if (c == '\\') {
        i += 2;
        continue;
      }
      if (c == '=' || c == ':' || Character.isWhitespace(c)) {
        break;
      }
      i++;
    }
    while (i < s.length() && Character.isWhitespace(s.charAt(i))) {
      i++;
    }
    if (i < s.length() && (s.charAt(i) == '=' || s.charAt(i) == ':')) {
      i++;
    }
    // A trailing '\' joins the continuation lines: only whitespace and joins means empty.
    for (; i < s.length(); i++) {
      char c = s.charAt(i);
      if (c == '\\' && i == s.length() - 1) {
        continue;
      }
      if (!Character.isWhitespace(c)) {
        return true;
      }
    }
    return false;
  }

  /** Writes the {@code \\uXXXX} escapes of visible characters as the characters. */
  static String unescapeVisible(String line) {
    StringBuilder out = new StringBuilder(line.length());
    for (int i = 0; i < line.length(); i++) {
      char c = line.charAt(i);
      if (c != '\\' || i + 1 >= line.length()) {
        out.append(c);
        continue;
      }
      char n = line.charAt(i + 1);
      if (n == 'u' && isHex(line, i + 2)) {
        char u = (char) Integer.parseInt(line.substring(i + 2, i + 6), 16);
        // ASCII escapes stay: '=' in a key, ' ' leading a value or '\' have a meaning.
        if (u >= 0x80 && visible(u)) {
          out.append(u);
          i += 5;
          continue;
        }
      }
      // Keep the escape pair as it is ('\\', '\=', '\n', an invisible '\\u...').
      out.append(c).append(n);
      i++;
    }
    return out.toString();
  }

  private static boolean isHex(String s, int from) {
    if (from + 4 > s.length()) {
      return false;
    }
    for (int k = from; k < from + 4; k++) {
      if (Character.digit(s.charAt(k), 16) < 0) {
        return false;
      }
    }
    return true;
  }

  /** Writes the characters above U+00FF as {@code \\uXXXX} escapes. */
  static String escapeAboveLatin1(String line) {
    StringBuilder out = new StringBuilder(line.length());
    for (int i = 0; i < line.length(); i++) {
      char c = line.charAt(i);
      if (c > 0xFF) {
        out.append("\\u%04X".formatted((int) c));
      } else {
        out.append(c);
      }
    }
    return out.toString();
  }

  /**
   * A character that can be seen: escapes of controls, format characters, surrogates and space
   * separators other than the plain space (a non-breaking space) are kept.
   */
  static boolean visible(char c) {
    return switch (Character.getType(c)) {
      case Character.CONTROL,
              Character.FORMAT,
              Character.SURROGATE,
              Character.PRIVATE_USE,
              Character.UNASSIGNED,
              Character.LINE_SEPARATOR,
              Character.PARAGRAPH_SEPARATOR ->
          false;
      case Character.SPACE_SEPARATOR -> c == ' ';
      default -> true;
    };
  }
}
